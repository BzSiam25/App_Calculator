package com.example.app_calculator;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    EditText ViewDisplay;
    Button btnClear, btnPercent, btnDivide, btnMultiply, btnSubtract, btnAdd, btnEquals, btnDot;
    Button btn0, btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9;
    Button btnSquare, btnCube, btnLog;

    private double runningTotal = 0;
    private String operator = "";
    private boolean isNewOperation = true;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize
        ViewDisplay = findViewById(R.id.ViewDisplay);
        btnClear = findViewById(R.id.btnClear);
        btnPercent = findViewById(R.id.btnPercent);
        btnEquals = findViewById(R.id.btnEquals);
        btnDot = findViewById(R.id.btnDot);
        btnDivide = findViewById(R.id.btnDivide);
        btnMultiply = findViewById(R.id.btnMultiply);
        btnSubtract = findViewById(R.id.btnSubtract);
        btnAdd = findViewById(R.id.btnAdd);
        btn0 = findViewById(R.id.btn0);
        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);
        btn3 = findViewById(R.id.btn3);
        btn4 = findViewById(R.id.btn4);
        btn5 = findViewById(R.id.btn5);
        btn6 = findViewById(R.id.btn6);
        btn7 = findViewById(R.id.btn7);
        btn8 = findViewById(R.id.btn8);
        btn9 = findViewById(R.id.btn9);
        btnSquare = findViewById(R.id.btnSquare);
        btnCube = findViewById(R.id.btnCuve);
        btnLog = findViewById(R.id.btnLog);

        // OnClickListener for number button
        btn0.setOnClickListener(v -> appendNumber("0"));
        btn1.setOnClickListener(v -> appendNumber("1"));
        btn2.setOnClickListener(v -> appendNumber("2"));
        btn3.setOnClickListener(v -> appendNumber("3"));
        btn4.setOnClickListener(v -> appendNumber("4"));
        btn5.setOnClickListener(v -> appendNumber("5"));
        btn6.setOnClickListener(v -> appendNumber("6"));
        btn7.setOnClickListener(v -> appendNumber("7"));
        btn8.setOnClickListener(v -> appendNumber("8"));
        btn9.setOnClickListener(v -> appendNumber("9"));

        // OnClickListener for functional button
        btnAdd.setOnClickListener(v -> setOperation("+"));
        btnSubtract.setOnClickListener(v -> setOperation("-"));
        btnMultiply.setOnClickListener(v -> setOperation("*"));
        btnDivide.setOnClickListener(v -> setOperation("/"));
        btnPercent.setOnClickListener(v -> setOperation("%"));
        btnDot.setOnClickListener(v -> appendDot());

        //  equals button
        btnEquals.setOnClickListener(v -> calculateResult());

        //  clear button
        btnClear.setOnClickListener(v -> clearDisplay());

        // Set up onClickListeners for new buttons (square, cube, log)
        btnSquare.setOnClickListener(v -> calculateSquare());
        btnCube.setOnClickListener(v -> calculateCube());
        btnLog.setOnClickListener(v -> calculateLog());
    }

    // Append number to the display
    private void appendNumber(String number) {
        if (isNewOperation) {
            ViewDisplay.setText(number);
            isNewOperation = false;
        } else {
            ViewDisplay.append(number);
        }
    }

    // Append a decimal point
    private void appendDot() {
        if (isNewOperation) {
            ViewDisplay.setText("0.");
            isNewOperation = false;
        } else if (!ViewDisplay.getText().toString().contains(".")) {
            ViewDisplay.append(".");
        }
    }

    // Set the operation
    private void setOperation(String op) {
        performCurrentOperation();
        operator = op;
        isNewOperation = true;
    }

    // Calculate the result
    private void calculateResult() {
        performCurrentOperation();
        // Remove trailing .0 if it's a whole number
        ViewDisplay.setText(formatResult(runningTotal));
        operator = "";  // Clear operator after calculation
        isNewOperation = true;
    }

    // Perform the current operation
    private void performCurrentOperation() {
        double currentNumber = Double.parseDouble(ViewDisplay.getText().toString());

        if (isNewOperation) {
            runningTotal = currentNumber;
        } else {
            switch (operator) {
                case "+":
                    runningTotal += currentNumber;
                    break;
                case "-":
                    runningTotal -= currentNumber;
                    break;
                case "*":
                    runningTotal *= currentNumber;
                    break;
                case "/":
                    if (currentNumber != 0) {
                        runningTotal /= currentNumber;
                    } else {
                        ViewDisplay.setText("Error");
                        return;
                    }
                    break;
                case "%":
                    runningTotal = runningTotal * currentNumber / 100;
                    break;
                default:
                    runningTotal = currentNumber;
                    break;
            }
        }
        // Display result
        ViewDisplay.setText(formatResult(runningTotal));
    }

    private String formatResult(double result) {
        if (result == (int) result) {
            return String.valueOf((int) result);  // Remove decimals if it's a whole number
        } else {
            return String.valueOf(result);
        }
    }

    //  Square
    private void calculateSquare() {
        double currentNumber = Double.parseDouble(ViewDisplay.getText().toString());
        runningTotal = currentNumber * currentNumber;
        ViewDisplay.setText(formatResult(runningTotal));
    }

    // Cube
    private void calculateCube() {
        double currentNumber = Double.parseDouble(ViewDisplay.getText().toString());
        runningTotal = currentNumber * currentNumber * currentNumber;
        ViewDisplay.setText(formatResult(runningTotal));
    }

    // Log (base 10)
    private void calculateLog() {
        double currentNumber = Double.parseDouble(ViewDisplay.getText().toString());
        if (currentNumber > 0) {
            runningTotal = Math.log10(currentNumber);
            ViewDisplay.setText(formatResult(runningTotal));
        } else {
            ViewDisplay.setText("Error");
        }
    }

    private void clearDisplay() {
        ViewDisplay.setText("0");
        runningTotal = 0;
        operator = "";
        isNewOperation = true;
    }
}
